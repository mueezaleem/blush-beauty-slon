BLUSH BEAUTY SALON & ACADEMY BY SAJIDA — WEBSITE
=================================================

FILES
- index.html
- styles.css
- script.js

BUSINESS DETAILS USED FROM GOOGLE MAPS
- Name: Blush Beauty Salon & Academy by Sajida
- Category: Beauty salon
- Rating: 4.8 / 5 (184 reviews at time of build)
- Phone: +92 342 2149499
- Address: Opposite Govt. Comprehensive Girls School, Bahadur Shah Road, Sargodha 40100, Pakistan
- Opening hours: Monday–Sunday, 10:00 AM–7:30 PM
- Map coordinates: 32.0771513, 72.678475

IMPORTANT
The Google Maps listing did not expose a detailed treatment menu through the available data.
To avoid inventing services, the Services section uses only broad enquiry categories:
Beauty Salon Services, Salon Appointments, and Academy & Training.

IMAGES
Editorial salon placeholder photography is loaded from Unsplash.
Replace the image URLs in index.html with official salon photos when available.

WHATSAPP
WhatsApp links use the business phone number from the Google Maps listing:
923422149499
Edit WHATSAPP_NUMBER in script.js if a different WhatsApp number is preferred.

HOW TO USE
Open index.html in any modern browser.
For deployment, upload all three files together while preserving filenames.
